<?php return array('dependencies' => array(), 'version' => '33887fff8894401280bb');
