<?php return array('dependencies' => array('react', 'wc-blocks-registry', 'wp-element'), 'version' => 'f1eea6d5630a68f09ba1');
