<?php return array('dependencies' => array('react', 'wc-blocks-registry', 'wp-element'), 'version' => '66d65dc555d2dc6a559d');
