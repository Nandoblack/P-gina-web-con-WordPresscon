<?php return array('dependencies' => array(), 'version' => '2531fca849602fe6f17f');
