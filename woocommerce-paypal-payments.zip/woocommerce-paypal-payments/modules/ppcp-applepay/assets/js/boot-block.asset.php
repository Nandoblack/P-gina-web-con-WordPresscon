<?php return array('dependencies' => array('wc-blocks-registry', 'wp-element'), 'version' => 'a537028c2343952ee2da');
