<?php return array('dependencies' => array(), 'version' => '68b36c7e47c44fc7de94');
