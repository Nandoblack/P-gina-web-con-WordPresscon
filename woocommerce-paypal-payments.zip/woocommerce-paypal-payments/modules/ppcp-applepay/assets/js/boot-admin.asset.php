<?php return array('dependencies' => array(), 'version' => 'f50d45fabfe8360dd0d4');
