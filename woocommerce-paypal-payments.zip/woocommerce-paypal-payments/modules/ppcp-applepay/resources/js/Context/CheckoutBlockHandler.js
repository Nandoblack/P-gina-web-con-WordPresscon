import BaseHandler from './BaseHandler';

class CheckoutBlockHandler extends BaseHandler {}

export default CheckoutBlockHandler;
