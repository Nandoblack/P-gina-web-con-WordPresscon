<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => '8b3e727c209b1ecab42c');
