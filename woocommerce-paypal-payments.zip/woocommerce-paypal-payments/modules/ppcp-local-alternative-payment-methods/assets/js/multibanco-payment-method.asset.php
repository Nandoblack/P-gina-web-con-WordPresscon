<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => 'e6f778906d15fe3df0a3');
