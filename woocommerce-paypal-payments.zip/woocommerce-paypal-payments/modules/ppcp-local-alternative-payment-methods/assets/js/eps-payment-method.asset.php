<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => '80391dfc6c79deb2d25d');
