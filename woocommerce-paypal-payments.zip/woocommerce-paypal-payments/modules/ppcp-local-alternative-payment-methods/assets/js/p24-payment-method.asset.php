<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => 'b522b365010c2c1e512d');
