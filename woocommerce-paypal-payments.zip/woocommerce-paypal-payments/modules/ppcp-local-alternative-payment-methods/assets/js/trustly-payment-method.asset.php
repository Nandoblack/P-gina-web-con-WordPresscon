<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => '3c92314182e5457f7987');
