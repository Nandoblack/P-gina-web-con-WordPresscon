<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => '412e0a6bc31a28b67879');
