<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => '3755a6f8e8624f48bfb2');
