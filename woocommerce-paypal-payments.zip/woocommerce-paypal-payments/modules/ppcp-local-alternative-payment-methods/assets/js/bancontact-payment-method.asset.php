<?php return array('dependencies' => array('wc-blocks-registry'), 'version' => '2c1353c2af810315674b');
