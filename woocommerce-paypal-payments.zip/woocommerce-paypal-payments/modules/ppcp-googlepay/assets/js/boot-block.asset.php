<?php return array('dependencies' => array('wc-blocks-registry', 'wp-element'), 'version' => '8b0eb5dac2761adc41f2');
