<?php return array('dependencies' => array(), 'version' => '503c3b3b00fae846c501');
