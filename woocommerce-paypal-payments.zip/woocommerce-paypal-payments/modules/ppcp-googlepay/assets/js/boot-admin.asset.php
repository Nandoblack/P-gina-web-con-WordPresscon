<?php return array('dependencies' => array(), 'version' => '79d6b2f56a5b991049aa');
